import base64
from datetime import datetime
import json
import os
import torch
from langchain.schema import Document
from langchain.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import shutil

def decode_base64(data):
    """
    Decode a base64 encoded clinical note into plain UTF-8 text.

    In FHIR, clinical notes are often embedded inside the 'DocumentReference' resource
    under the 'content.attachment.data' field in base64 format. This function will help
    convert that encoded data back into readable text.

    Args:
        data (str): Base64 encoded string from a FHIR DocumentReference.

    Returns:
        str: Decoded UTF-8 clinical note as plain text.
    """
    # TODO: Replace None below with code to Decode the base64 string and store the result in decoded_clinical_note

    decoded_clinical_note = None  
    return decoded_clinical_note

def extract_notes(bundle, resource_type, resource_attribute):
    """Extract document references and decode notes from FHIR Bundle."""
    notes = []
    document_reference_count = 0
    for entry in bundle.get('entry', []):
        resource = entry.get('resource')
        if resource and resource.get('resourceType') == resource_type:
            document_reference_count += 1
            content = resource.get('content', [])
            for item in content:
                if item.get(resource_attribute, {}).get('contentType', '') == 'text/plain; charset=utf-8':
                    note_data = item.get(resource_attribute, {}).get('data')
                    if note_data:
                        # Hint: Use the decode_base64 function to convert note_data into plain text
                        # TODO:  Replace None below with actual Functional
                        note_text = None
                        if note_text.strip().lower() == "none":
                            note_text = "[No clinical note content available.]"

                        note_info = {
                            "date": resource.get('date'),
                            "doctor": resource.get('author', [{}])[0].get('display', 'Unknown Doctor'),
                            "organization": resource.get('custodian', {}).get('display', 'Unknown Organization'),
                            "note": note_text
                        }
                        notes.append(note_info)
    return notes, document_reference_count

def count_diagnostic_report(bundle, resource_type, resource_attribute):
    """Count Number of DiagnosticReport from FHIR Bundle."""
    notes = []
    diagnostic_report_count = 0
    for entry in bundle.get('entry', []):
        resource = entry.get('resource')
        if resource and resource.get('resourceType') == resource_type:
            diagnostic_report_count += 1
            
    return diagnostic_report_count


def format_notes(notes):
    """Format notes into the required text format."""
    formatted_notes = []
    for note in notes:
        date_str = datetime.strptime(note['date'], '%Y-%m-%dT%H:%M:%S.%f%z').strftime('%Y-%m-%d %H:%M:%S')
        formatted_note = (
            f"Date: {date_str}\n"
            f"Doctor: {note['doctor']}\n"
            f"Organization: {note['organization']}\n"
            f"\n{note['note']}\n"
            f"End of Clinical Note, Date of Clinical note\n"
        )
        formatted_notes.append(formatted_note)
    return formatted_notes

def save_notes_to_file(notes, filename):
    """Save formatted notes to a text file."""
    with open(filename, 'w', encoding='utf-8') as file:
        for note in notes:
            file.write(note)

def check_and_load_config(config_path):
    with open(config_path, 'r', encoding='utf-8') as file:
        config = json.load(file)
    
    tasks = config.get('tasks', {})
    task1 = tasks.get('task1_read_fhir_bundle', {})
    task2 = tasks.get('task2_vector_db_and_genai_model_config', {})
    
    # Check task1
    missing_keys_task1 = [key for key in ['bundle_name', 'transaction_type', 'output_filename', 'resource_type', 'resource_attribute'] if not task1.get(key)]
    if missing_keys_task1:
        print(f"Missing configuration for task1_read_fhir_bundle: {', '.join(missing_keys_task1)}")
        return None
    
    # Check task2
    missing_keys_task2 = [key for key in ['embedding_name', 'input_clinical_note_file', 'model_name'] if not task2.get(key)]
    if missing_keys_task2:
        print(f"Missing configuration for task2_vector_db_and_genai_model_config: {', '.join(missing_keys_task2)}")
        return None
    
    return config

def update_result(result, task_name, status, message, task_config, document_reference_count=None,diagnostic_report_count=None):
    if task_name not in result:
        result[task_name] = []
    result_entry = {
        "timestamp": datetime.now().isoformat(),
        "status": status,
        "message": message,
        "ResourceType": task_config['resource_type'],
        "ResourceAttribute": task_config['resource_attribute'],
        "AddtionalResourceType": task_config['additional_resource_type'],
        "AddtionalResourceAttribute": task_config['additional_resource_attribute'],
        "bundle_name": task_config['bundle_name']
    }
    if document_reference_count is not None:
        result_entry["document_reference_count"] = document_reference_count
    
    if diagnostic_report_count is not None:
        result_entry["diagnostic_report_count"] = diagnostic_report_count
        
    result[task_name].append(result_entry)

def update_vector_db_result(result, status, message, config):
    result["vector_db_and_genai_model_loading_status"] = {
        "timestamp": datetime.now().isoformat(),
        "status": status,
        "message": message,
        "embedding_name": config["embedding_name"],
        "input_clinical_note_file": config["input_clinical_note_file"],
        "model_name": config["model_name"]
    }

def save_result(result, result_filename):
    with open(result_filename, 'w', encoding='utf-8') as file:
        json.dump(result, file, indent=4)

def process_task(task_name, task_config, result):
    
    bundle_json_path = task_config['bundle_name']
    output_filename = task_config['output_filename']
    
    resource_type = task_config['resource_type']
    resource_attribute = task_config['resource_attribute']
    
    additional_resource_type = task_config['additional_resource_type']
    additional_resource_attribute = task_config['additional_resource_attribute']
    
    
    try:
        with open(bundle_json_path, 'r', encoding='utf-8') as file:
            bundle = json.load(file)
        
        notes, document_reference_count = extract_notes(bundle, resource_type, resource_attribute)
        diagnostic_report_count = count_diagnostic_report(bundle, additional_resource_type, additional_resource_attribute)
        notes.sort(key=lambda x: x['date'], reverse=True)
        formatted_notes = format_notes(notes)
        save_notes_to_file(formatted_notes, output_filename)
        
        update_result(result, task_name, "success", f"Notes have been saved to {output_filename}", task_config, document_reference_count,diagnostic_report_count)

        print(f"Clinical Notes extracted successfully and saved to '{output_filename}'.")
        print("Please take a look at the synthetic data.")
        print("Kindly analyze it and share your thoughts in the class forum on how we might generate better synthetic data.")
    except Exception as e:
        print("\n⚠️ Clinical Note Extraction Failed.")
        print("Please make sure you have completed the required coding for the functions:")
        print("  - `decode_base64`")
        print("  - `extract_notes`")
        print("If you've tried multiple times and it's still not working, a reference implementation is available in `code_solution.py`.")
        print("You can copy both functions from that file and replace them in `experiments.py`.\n")
        update_result(result, task_name, "failure", str(e), task_config)

def main_read_fhir_bundle(config):
    tasks = config.get('tasks', {})
    result = {}
    for task_name, task_config in tasks.items():
        if task_name.startswith("task1_"):
            process_task(task_name, task_config, result)
    
    # Generate result filename based on the input bundle file name
    bundle_name = os.path.basename(tasks['task1_read_fhir_bundle']['bundle_name'])
    result_filename = f"{os.path.splitext(bundle_name)[0]}_result.json"
    
    save_result(result, result_filename)

class TextFileLoader:
    def __init__(self, file_path):
        self.file_path = file_path

    def load(self):
        with open(self.file_path, 'r') as file:
            text = file.read()
        return [Document(page_content=text)]

def process_vector_db_and_genai_model_config(config, result):
    global rag_retriever, flan_t5_tokenizer, flan_t5_model, device

    try:
        # Load embeddings
        try:
            embeddings = HuggingFaceEmbeddings(
              model_name=config["embedding_name"], 
              model_kwargs={"trust_remote_code": True}
            )
        except Exception as e:
            msg = f"Failed to load embeddings: {e}"
            print(msg)  # Show in notebook output
            raise RuntimeError(msg)

        # Process documents and create vector store
        try:
            file_name = os.path.basename(config['bundle_name']).rsplit('.json', 1)[0]
            rag_store = f"./rag_store/{file_name}_rag_store"

            if os.path.exists(rag_store) and os.path.isdir(rag_store):
                shutil.rmtree(rag_store)

            rag_loader = TextFileLoader(config["input_clinical_note_file"])
            rag_docs = rag_loader.load()
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
            rag_splits = text_splitter.split_documents(rag_docs)
            rag_vectorstore = Chroma.from_documents(documents=rag_splits, embedding=embeddings, persist_directory=rag_store)
            rag_retriever = rag_vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 1})
        except KeyError as e:
            msg = f"Missing key in configuration: {e}"
            print(msg)
            raise KeyError(msg)
        except Exception as e:
            msg = f"Failed to process raw documents and create vector store: {e}"
            print(msg)
            raise RuntimeError(msg)

        # Load model
        try:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            flan_t5_tokenizer = AutoTokenizer.from_pretrained(config["model_name"])
            flan_t5_model = AutoModelForSeq2SeqLM.from_pretrained(config["model_name"]).to(device)
        except Exception as e:
            msg = f"Failed to load models: {e}"
            print(msg)
            raise RuntimeError(msg)

        msg = "Vector DB and models loaded successfully."
        print(msg)
        update_vector_db_result(result, "success", msg, config)

    except Exception as e:
        error_message = f"Error in process_vector_db_and_genai_model_config: {e}"
        print(error_message)  # Ensure error appears in notebook output
        update_vector_db_result(result, "failure", error_message, config)


def main_vector_db_and_genai_model_config(config):
    
    tasks = config.get('tasks', {})
    bundle_name = os.path.basename(tasks['task1_read_fhir_bundle']['bundle_name'])
    result_filename = f"{os.path.splitext(bundle_name)[0]}_result.json"
    
    vector_db_config = config['tasks'].get('task2_vector_db_and_genai_model_config', {})
    
    
    # Load the existing result file
    if os.path.exists(result_filename):
        with open(result_filename, 'r', encoding='utf-8') as file:
            result = json.load(file)
    else:
        result = {}

    process_vector_db_and_genai_model_config(vector_db_config, result)
    
    save_result(result, result_filename)

def perform_vector_db_query(question, retriever, summary="No"):
    retrieved_docs = retriever.invoke(question)
    context = "\n\n".join(doc.page_content for doc in retrieved_docs)
    context = context.replace('#', '')
   
    
    if summary == "Yes":
        t5_prompt = f"summarize: {context}"
    else:
        t5_prompt = f"""

        [Context]: {context}\n\n
        
        [Question]: {question}\n\n
        [Answer]:
        """

    return context, t5_prompt

def get_model_answer(t5_prompt, tokenizer, model,config):
    input_ids = tokenizer(t5_prompt, return_tensors='pt').input_ids.to(device)
    outputs = model.generate(
        input_ids=input_ids, 
        max_new_tokens=50
    )
    answer = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
    return answer

def main_question_answering(config, summary):
    question_config = config['tasks'].get('task3_question_answering', {}).get('questions', {})
    
    tasks = config.get('tasks', {})
    bundle_name = os.path.basename(tasks['task1_read_fhir_bundle']['bundle_name'])
    result_filename = f"{os.path.splitext(bundle_name)[0]}_result.json"
    
    # Load the existing result file
    if os.path.exists(result_filename):
        with open(result_filename, 'r', encoding='utf-8') as file:
            result = json.load(file)
    else:
        result = {}

    question_answers = {}
    for key, question in question_config.items():
        # Show current question
        print(f"\n🧠 Question [{key}]: {question}\n")

        context, t5_prompt = perform_vector_db_query(question, rag_retriever, summary)
        model_answer = get_model_answer(t5_prompt, flan_t5_tokenizer, flan_t5_model, config)

        # Show generated answer
        print(f"💬 Model Answer:\n{model_answer}\n{'-'*50}")

        question_answers[key] = {
            "question": question,
            "context": context,
            "model_answer": model_answer
        }

    result["question_answering"] = question_answers
    save_result(result, result_filename)


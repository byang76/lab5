import json
import os
import openai
from experiments import main_read_fhir_bundle, main_vector_db_and_genai_model_config, main_question_answering

# Function to load the experiments.json file
def load_experiment_config(config_path):
    with open(config_path, 'r', encoding='utf-8') as file:
        return json.load(file)

# Function to save the experiments.json file
def save_experiment_config(config_path, config):
    with open(config_path, 'w', encoding='utf-8') as file:
        json.dump(config, file, indent=4)

# Function to check if all required fields are filled
def check_config(config):
    tasks = config.get('tasks', {})
    task1 = tasks.get('task1_read_fhir_bundle', {})
    task2 = tasks.get('task2_vector_db_and_genai_model_config', {})
    
    # Check task1
    missing_keys_task1 = [key for key in ['bundle_name', 'transaction_type', 'output_filename', 'resource_type', 'resource_attribute'] if not task1.get(key)]
    if missing_keys_task1:
        print(f"Missing configuration for task1_read_fhir_bundle: {', '.join(missing_keys_task1)}")
        return False
    
    # Check task2
    missing_keys_task2 = [key for key in ['embedding_name', 'input_clinical_note_file', 'model_name', 'fine_tuned_model_name'] if not task2.get(key)]
    if missing_keys_task2:
        print(f"Missing configuration for task2_vector_db_and_genai_model_config: {', '.join(missing_keys_task2)}")
        return False

    return True


import os
from openai import OpenAI

# Function to set the OpenAI API key
def set_openai_api_key():
    try:
        with open('openai_key.txt', 'r') as file:
            openai_api_key = file.read().strip()
            os.environ["OPENAI_API_KEY"] = openai_api_key
            return openai_api_key
    except FileNotFoundError:
        print("Error: 'openai_key.txt' not found and 'OPENAI_API_KEY' environment variable is not set.")
        return None

# Function to call the LLM API
def call_llm_api(prompt):
    """Call the LLM API to get a response for a given prompt."""
    api_key = set_openai_api_key()
    if not api_key:
        return
    
    
    client = openai.OpenAI(api_key=api_key)
    
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are an expert in medical text analysis."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=150
    )
    return response.choices[0].message.content.strip()

# Function to run the main experiments
def run_experiments(config, use_openai=False):
    if check_config(config):
        main_read_fhir_bundle(config)
        main_vector_db_and_genai_model_config(config)
        main_question_answering(config)
        
        if use_openai:
            add_openai_answers(config)
    else:
        print("Please ensure all required configuration values are provided.")

# Function to add OpenAI answers
def add_openai_answers(config):
    tasks = config.get('tasks', {})
    bundle_name = os.path.basename(tasks['task1_read_fhir_bundle']['bundle_name'])
    result_filename = f"{os.path.splitext(bundle_name)[0]}_result.json"
    
    # Load the existing result file
    if os.path.exists(result_filename):
        with open(result_filename, 'r', encoding='utf-8') as file:
            result = json.load(file)
    else:
        result = {}

    question_config = config['tasks'].get('task3_question_answering', {}).get('questions', {})

    for key, value in result.get("question_answering", {}).items():
        if key in question_config:
            question = question_config[key]
            context = value.get("context", "")
            prompt = f"Question: {question}\nContext: {context}"
            openai_answer = call_llm_api(prompt)
            value["openai_answer"] = openai_answer
    
    # Save the updated result
    save_result(result, result_filename)

def save_result(result, result_filename):
    with open(result_filename, 'w', encoding='utf-8') as file:
        json.dump(result, file, indent=4)

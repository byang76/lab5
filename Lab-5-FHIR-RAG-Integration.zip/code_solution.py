def decode_base64(data):
    """Decode base64 encoded data."""
    return base64.b64decode(data).decode('utf-8')

def extract_notes(bundle, resource_type, resource_attribute):
    """Extract document references and decode notes from FHIR Bundle."""
    notes = []
    document_reference_count = 0
    for entry in bundle.get('entry', []):
        resource = entry.get('resource')
        if resource and resource.get('resourceType') == resource_type:
            document_reference_count += 1
            content = resource.get('content', [])
            for item in content:
                if item.get(resource_attribute, {}).get('contentType', '') == 'text/plain; charset=utf-8':
                    note_data = item.get(resource_attribute, {}).get('data')
                    if note_data:
                        note_text = decode_base64(note_data)
                        if note_text.strip().lower() == "none":
                            note_text = "[No clinical note content available.]"

                        note_info = {
                            "date": resource.get('date'),
                            "doctor": resource.get('author', [{}])[0].get('display', 'Unknown Doctor'),
                            "organization": resource.get('custodian', {}).get('display', 'Unknown Organization'),
                            "note": note_text
                        }
                        notes.append(note_info)
    return notes, document_reference_count
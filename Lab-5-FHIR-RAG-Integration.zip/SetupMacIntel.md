# Setup Instructions for macOS (Intel CPU)

These instructions will guide you to set up a development environment for this project on macOS with an Intel processor.

---

## 🔧 Prerequisites

* [Homebrew](https://brew.sh) installed
* Internet connection (to download models and dependencies)

---

## 1. Install pyenv and Python 3.10

```bash
brew install pyenv
pyenv install 3.10.13
```

Ensure shell integration is set up in your `~/.zshrc`:

```bash
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"
```

Reload your terminal or run:

```bash
source ~/.zshrc
```

---

## 2. Create and activate a virtual environment

```bash
pyenv shell 3.10.13
python -m venv venv310
source venv310/bin/activate
```

---

## 3. Install requirements

Use the platform-specific requirements file:

```bash
pip install --upgrade pip
pip install -r requirements_local_mac_intel.txt
```

> ⚠️ If you hit NumPy or PyTorch issues, manually enforce versions:

```bash
pip install "torch==2.2.2" "numpy<2.0"
```

---

## 4. Run the experiment

```bash
python experiments_local.py
```

If running for the first time, it may take several minutes to download model weights (e.g., \~1GB).

---

## ✅ Notes

* **PyTorch 2.3+** is not available for Intel macOS — use `torch==2.2.2`.
* **Python 3.13 is not supported** — use Python 3.10 or 3.9.
* **NumPy 2.x breaks compatibility** with many compiled modules — use `numpy<2.0`.
* **LangChain deprecations** may show warnings; they can be resolved by updating imports later.

---

## 🛀 Optional Cleanup

To remove the environment:

```bash
deactivate
rm -rf venv310
```

To uninstall Python version:

```bash
pyenv uninstall 3.10.13
```

---

## 📆 Reference: `requirements_local_mac_intel.txt`


# ===============================================
# 🔧 Configuration Section - Student Editable Part
# ===============================================

# Replace <Number> with patient number (e.g., 1, 2, 3...)
bundle_name = "fhir_bundles/patient1.json"  # 📝 STUDENT TODO

# Replace <bundle_type> with actual FHIR bundle type (e.g., 'document', 'transaction')
transaction_type = "transaction"  # 📝 STUDENT TODO

# Replace <resource_type> with actual FHIR resource type (e.g., 'DocumentReference')
resource_type = "DocumentReference"  # 📝 STUDENT TODO

# ===============================================
# 📦 Import Modules & Load Config
# ===============================================

from experiment_helpers import load_experiment_config
from experiments import main_read_fhir_bundle, main_vector_db_and_genai_model_config, main_question_answering

config_path = 'experiments.json'
config = load_experiment_config(config_path)

# Setup Task 1: Reading the FHIR Bundle
config['tasks']['task1_read_fhir_bundle'].update({
    'bundle_name': bundle_name,
    'transaction_type': transaction_type,
    'resource_type': resource_type,
    'resource_attribute': "attachment",
    'additional_resource_type': "DiagnosticReport",
    'additional_resource_attribute': "presentedForm"
})

# 🧪 Task 1: Implement decode_base64() and extract_notes() in experiments.py before running
#
# You need to finish two functions marked with TODOs in the file `experiments.py`:
#
# 1. decode_base64(data)
#    - Find the line:
#        # TODO: Replace None below with code to Decode the base64 string...
#
# 2. extract_notes(...)
#    - Find the line:
#        # TODO: Replace None below with actual decoded function call
#
# 📂 If needed, check code_solution.py for the complete implementation as reference.
# ▶️ Once completed, run `main_read_fhir_bundle(config)` below to read clinical notes.
main_read_fhir_bundle(config)

# ===============================================
# ⚙️ Task 2: Vector DB + LLM Setup
# ===============================================

embedding_name = "nomic-ai/nomic-embed-text-v1"  # DO NOT CHANGE
input_clinical_note_file = "clinical_notes_output.txt"  # DO NOT CHANGE
model_name = "google/flan-t5-base"  # DO NOT CHANGE
temperature = 0.3  # DO NOT CHANGE

config['tasks']['task2_vector_db_and_genai_model_config'].update({
    'bundle_name': bundle_name,
    'temperature': temperature,
    'embedding_name': embedding_name,
    'input_clinical_note_file': input_clinical_note_file,
    'model_name': model_name
})

main_vector_db_and_genai_model_config(config)

# ===============================================
# 🤖 Task 3: Question Answering
# ===============================================
main_question_answering(config, "No")

# ===============================================
# 📊 Task 4: Evaluation
# ===============================================

import nltk
nltk.download('wordnet')
import json
import os
import matplotlib.pyplot as plt
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge import Rouge
from nltk.translate.meteor_score import meteor_score
import bert_score
import logging
import warnings

warnings.filterwarnings("ignore")
logging.getLogger("transformers.modeling_utils").setLevel(logging.ERROR)

smoothing_function = SmoothingFunction().method4
rouge = Rouge()

def evaluate_answers(student_data, openai_answers):
    """
    Evaluate model answers against OpenAI answers using BLEU, ROUGE, METEOR, and BERTScore.

    Args:
        student_data (dict): The student file data.
        openai_answers (dict): The OpenAI answers.

    Returns:
        tuple: A tuple containing questions, relative scores, detailed results, and error message (if any).
    """
    relative_scores = []
    questions = []
    results = {}

    if 'question_answering' not in student_data:
        return None, None, None, "No 'question_answering' key found in student data"

    for key, qa in student_data['question_answering'].items():
        question = qa.get('question', 'No question provided')
        model_answer = qa['model_answer']
        openai_answer = openai_answers['question_answering'].get(key, {}).get('openai_answer', "")

        if not openai_answer:
            logging.warning(f"No OpenAI answer found for question: {key}")
            continue

        questions.append(key)

        # Tokenize the answers
        model_answer_tokens = model_answer.split()
        openai_answer_tokens = openai_answer.split()

        # Calculate BLEU Score
        try:
            bleu = sentence_bleu([openai_answer_tokens], model_answer_tokens, smoothing_function=smoothing_function)
        except ZeroDivisionError:
            bleu = 0.0
            logging.warning(f"BLEU score calculation failed for question: {key}")

        # Calculate ROUGE Score
        try:
            rouge_score = rouge.get_scores(' '.join(model_answer_tokens), ' '.join(openai_answer_tokens), avg=True)
            rouge_l_f = rouge_score['rouge-l']['f']
        except Exception as e:
            rouge_l_f = 0.0
            logging.warning(f"ROUGE score calculation failed for question: {key} with error {str(e)}")

        # Calculate METEOR Score
        try:
            meteor = meteor_score([openai_answer_tokens], model_answer_tokens)
        except Exception as e:
            meteor = 0.0
            logging.warning(f"METEOR score calculation failed for question: {key} with error {str(e)}")

        # Calculate BERTScore
        try:
            P, R, F1 = bert_score.score([model_answer], [openai_answer], lang="en", verbose=False)
            bert_f1 = F1.mean().item()
        except Exception as e:
            bert_f1 = 0.0
            logging.warning(f"BERTScore calculation failed for question: {key} with error {str(e)}")

        # Logic to determine final score
        if bert_f1 > 0:
            if bleu > 0.1 or rouge_l_f > 0.1 or meteor > 0.1:
                relative_score = bert_f1
            else:
                relative_score = bert_f1 * 0.3  # Reduce score if other scores are very low
        else:
            relative_score = 0.0

        relative_scores.append(relative_score * 100)  # Convert to percentage

        # Save individual results
        results[key] = {
            "question": question,
            "model_answer": model_answer,
            "openai_answer": openai_answer,
            "bleu_score": bleu,
            "rouge_l_f_score": rouge_l_f,
            "meteor_score": meteor,
            "bert_score": bert_f1,
            "final_percentage": relative_score * 100
        }

    return questions, relative_scores, results, None

# ===============================================
# ✅ Task 5: Run Evaluation
# ===============================================

def run_evaluation():
    patient_number = bundle_name.split('/')[-1].replace('patient', '').replace('.json', '')
    student_file_path = f'patient{patient_number}_result.json'
    openai_answer_file_path = f'openai_answer/{patient_number}.json'

    try:
        with open(student_file_path, 'r') as student_file, open(openai_answer_file_path, 'r') as openai_answer_file:
            student_data = json.load(student_file)
            openai_answers = json.load(openai_answer_file)

            questions, relative_scores, results, error = evaluate_answers(student_data, openai_answers)

            if error:
                print(f"Error in file {student_file_path}: {error}")
            else:
                # Save results to JSON file
                experiment_dir = f'submission/experiment{patient_number}'
                os.makedirs(experiment_dir, exist_ok=True)
                experiment_result_path = os.path.join(experiment_dir, 'experiment_result.json')
                with open(experiment_result_path, 'w') as experiment_result_file:
                    json.dump(results, experiment_result_file, indent=4)
                print(f"Results saved to {experiment_result_path}")

    except FileNotFoundError as e:
        logging.error(f"File not found: {e.filename}")
    except json.JSONDecodeError as e:
        logging.error(f"Error decoding JSON: {str(e)}")
    except Exception as e:
        logging.error(f"An unexpected error occurred: {str(e)}")

run_evaluation()

# ===============================================
# ✅ Task 6: Test Result Comparison
# ===============================================
EXPERIMENT_PATH = './submission'
RESULTS_PATH = './results'
TOLERANCE = 0.05

def read_json_content(path):
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return None

def write_json_content(path, content):
    with open(path, 'w') as f:
        json.dump(content, f, indent=4)

def check_values(obj):
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key != "openai_answer":  # Skip the optional openai_answer attribute
                check_values(value)
    elif isinstance(obj, list):
        for item in obj:
            check_values(item)
    else:
        assert obj is not None and obj != "", "Found empty or None value"

def _test_patient_results(experiment_num):
    # Build the paths to the JSON files in both directories
    submission_file = os.path.join(EXPERIMENT_PATH, f"experiment{experiment_num}", "experiment_result.json")
    result_file = os.path.join(RESULTS_PATH, f"experiment{experiment_num}", "experiment_result.json")

    # Load the JSON content from both files
    submission_content = read_json_content(submission_file)
    result_content = read_json_content(result_file)

    # If any of the files are not found, skip the test with a user-friendly message
    if submission_content is None:
        print(f"Experiment {experiment_num} skipped: Submission result file '{submission_file}' not found.")
        return False

    if result_content is None:
        print(f"Experiment {experiment_num} skipped: Result file '{result_file}' not found.")
        return False

    # Check the scores for each question in the experiment result
    for question_key, question_data in submission_content.items():
        result_question_data = result_content.get(question_key, None)

        if not result_question_data:
            print(f"Result for {question_key} not found in experiment {experiment_num}")
            return False

        for metric in ["bleu_score", "rouge_l_f_score", "meteor_score", "bert_score"]:
            student_score = question_data.get(metric, 0)
            result_score = result_question_data.get(metric, 0)

            # Ignore comparisons if either score is zero
            if student_score == 0 or result_score == 0:
                continue

            if student_score < result_score - TOLERANCE:
                print(f"{metric} for {question_key} in experiment {experiment_num} is below the threshold. Expected >= {result_score - TOLERANCE}, got {student_score}")
                return False

    print(f"Experiment {experiment_num} passed.")
    return True

def run_all_tests():
    required_tests = [1, 4, 8]
    tests_passed = {num: False for num in required_tests}
    for experiment_num in required_tests:
        if _test_patient_results(experiment_num):
            tests_passed[experiment_num] = True

    all_required_tests_passed = all(tests_passed.values())

    submission_file = os.path.join(".", 'submission.json')
    submission_content = read_json_content(submission_file)
    if submission_content is not None:
        if all_required_tests_passed:
            submission_content['state'] = '1'
            print("Required tests passed. Updating 'submission.json' state to 1.")
        else:
            print("Not all required tests passed. 'submission.json' state remains unchanged.")
        write_json_content(submission_file, submission_content)
    else:
        print("'submission.json' file not found.")

run_all_tests()

# ===============================================
# ✅ Task 7: Package Submission
# ===============================================

def zip_submission_folder():
    EXPERIMENT_PATH = './submission'
    ZIP_PATH = './submission.zip'

    if os.path.exists(ZIP_PATH):
        os.remove(ZIP_PATH)
    import shutil
    shutil.make_archive(EXPERIMENT_PATH, 'zip', EXPERIMENT_PATH)
    print(f"Submission folder zipped successfully into {ZIP_PATH}.")

def package_if_ready():
    submission_content = read_json_content('submission.json')
    if submission_content is not None:
        if submission_content.get('state') == '1':
            zip_submission_folder()
        else:
            print("'submission.json' state is not '1'. No zipping performed.")
    else:
        print("'submission.json' file not found.")

package_if_ready()

# ✅ End of Script
